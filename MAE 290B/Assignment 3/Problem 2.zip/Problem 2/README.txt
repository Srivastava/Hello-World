The code is in Python. You have to have installed python in your system to run the code

To run the code just type in command line python name.py

Example python RK3Advection.py


Thank you
