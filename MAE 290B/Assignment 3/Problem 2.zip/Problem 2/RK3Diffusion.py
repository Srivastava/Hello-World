import scipy as sp
import numpy as np
import matplotlib.pyplot as plt
import math as mt

#Imports

#Time Step
dx=0.01

#Final Time
timeFinal=float(10)

#Final X
xFinal=1

#Number of Steps
timeStep=10000

#Each time step
dt=timeFinal/timeStep

#number of steps in x equivalently number of grid points in x
nx=int(1/dx)

#alpha and U values
a=0.005
u=0.0

#initialialization
Ti=sp.zeros([nx])
T=sp.zeros([nx])

#deltaX square
dx2=dx**2

#initializing the conditions
for i in range(nx):
    if(i*dx<=0.5 and i*dx>=0.2):
        Ti[i]=np.sin(20*np.pi*i*dx)+np.sin(10*np.pi*i*dx)

#calculating the analytical solutions
def analytical(tval):
    xval=np.linspace(0, xFinal, nx)
    Ta=sp.zeros([nx])

    for i in range(nx):
        if(i*dx<=0.5 and i*dx>=0.2):
            Ta[i]=np.sin(10*np.pi*i*dx)*mt.exp(-100*np.pi*np.pi*a*tval)+np.sin(20*np.pi*i*dx)*mt.exp(-400*np.pi*np.pi*a*tval);

    return Ta

#Time Evolution of the function
def evolve(T,Ti):
    global nx,a
    k1=sp.zeros([nx])
    k2=sp.zeros([nx])
    k3=sp.zeros([nx])

    #RKW3 Method
    Ti[0]=1
    Ti[nx-1]=0


    k1[1:-1]=a*(Ti[2 : ] - 2*Ti[1:-1] + Ti[:-2])/dx2 - u*0.5*(Ti[2 : ]-Ti[:-2])/(dx)
    Ti[1:-1]=Ti[1:-1]+(8.0/15.0)*dt*k1[1:-1]

    k2[1:-1]=a*(Ti[2 : ] - 2*Ti[1:-1] + Ti[:-2])/dx2 - u*0.5*(Ti[2 : ]-Ti[:-2])/(dx)
    Ti[1:-1]=Ti[1:-1]+(5.0/12.0)*dt*k2[1:-1]-(17.0/60.0)*dt*k1[1:-1]

    k3[1:-1]=a*(Ti[2 : ] - 2*Ti[1:-1] + Ti[:-2])/dx2 - u*0.5*(Ti[2 : ]-Ti[:-2])/(dx)
    Ti[1:-1]=Ti[1:-1]+(3.0/4.0)*dt*k3[1:-1]-(5.0/12.0)*dt*k2[1:-1]

    Ti[0]=1
    Ti[nx-1]=0

    return Ti



#Setting up the plots for Visualization
x=np.linspace(0, xFinal, nx)
fig,ax=plt.subplots()

points, = ax.plot(x,Ti,color='r',label='Numerical Solution')
points1,=ax.plot(x,Ti,color='b',label='Analytical Solution')

plt.ylim([-3,3])
ax.legend([points,points1], [points.get_label(),points1.get_label()])
text=plt.text(0.1,1,"Pure Diffusion at t=0",ha='center',va='top',transform = ax.transAxes,fontsize='18')

plt.hold(False)

#main function which calculates our functions
for m in range(0, timeStep):

    Ta=analytical(m*dt)
    Ti=evolve(T,Ti)

    points.set_data(x,Ti)
    points1.set_data(x,Ta)

    plt.grid(True)
    timeEl=m*dt
    if(timeEl==0 or timeEl==0.01 or timeEl==1 or timeEl==100):
        fig.savefig('FigureD'+str(timeEl)+'.png')

    plt.xlabel('x')
    plt.ylabel('T(x)')
    text.set_text("t=: {0}".format(timeEl))
    plt.title('Pure Diffusion using RK3 in time and Central Difference in Space')

    plt.pause(0.000000005)
