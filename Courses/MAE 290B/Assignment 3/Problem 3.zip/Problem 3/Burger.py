import scipy as sp
import numpy as np
import matplotlib.pyplot as plt

#delta x
dx=0.01

#Final Time
timeFinal=float(100)

#Final X
xFinal=1

#Number of Steps to take
timeStep=100000

#Each Time Dtep
dt=timeFinal/timeStep

#Numeber of grid points in X
nx=int(10/dx)

#Initialization
Ti=sp.zeros([nx])
T=sp.zeros([nx])

#Setting up initial conditions
for i in range(nx):
    if(i*dx<=1 and i*dx>=0):
        Ti[i]=i*dx

    elif(i*dx<=2 and i*dx>=1):
        Ti[i]=2-i*dx

#Time evolution
def evolve(T,Ti):
    global nx,a
    k1=sp.zeros([nx])
    k2=sp.zeros([nx])
    k3=sp.zeros([nx])

    k1[1:-1]=-0.25*(Ti[2 : ]*Ti[2 : ]-Ti[:-2]*Ti[:-2])/dx
    Ti[1:-1]=Ti[1:-1]+(8.0/15.0)*dt*k1[1:-1]

    k2[1:-1]=-0.25*(Ti[2 : ]*Ti[2 : ]-Ti[:-2]*Ti[:-2])/dx
    Ti[1:-1]=Ti[1:-1]+(5.0/12.0)*dt*k2[1:-1]-(17.0/60.0)*dt*k1[1:-1]

    k3[1:-1]=-0.25*(Ti[2 : ]*Ti[2 : ]-Ti[:-2]*Ti[:-2])/dx
    Ti[1:-1]=Ti[1:-1]+(3.0/4.0)*dt*k3[1:-1]-(5.0/12.0)*dt*k2[1:-1]

    return Ti


#setting up for visualization
x=np.linspace(0, 10, nx)
fig,ax=plt.subplots()

points, = ax.plot(x,Ti,color='r',label='Numerical Solution')
text=plt.text(0.9,1,"Burgers Equation at t=0",ha='center',va='top',transform = ax.transAxes,fontsize='18')
plt.hold(False)

#main function which calculates values
for m in range(0, timeStep+1):

    Ti=evolve(T,Ti)

    plt.xlabel('x')
    plt.ylabel('u(x)')
    plt.grid(True)

    plt.title('Burgers Equation using RK3 in time and Central Difference in Space')

    timeEl=m*dt
    text.set_text("t=: {0}".format(timeEl))
    points.set_data(x,Ti)

    if(timeEl==0 or timeEl==0.5 or timeEl==1 or timeEl==1.5 or  timeEl==5 or timeEl==10):
        fig.savefig('FigureBurger'+str(timeEl)+'.png')


    plt.pause(0.000000005)
