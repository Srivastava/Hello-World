import scipy as sp
import numpy as np
import matplotlib.pyplot as plt

#Delta X
dx=0.01

#Final TIme
timeFinal=float(100)

#Number of Time Steps
timeStep=10000

#Each Time step
dt=timeFinal/timeStep

#Number of grid points in X
nx=int(10/dx)

#Initialitization
Ti=sp.zeros([nx])
T=sp.zeros([nx])

#Setting up Initial Conditions
for i in range(nx):
    if(i*dx<=1 and i*dx>=0):
        Ti[i]=i*dx

    if(i*dx<=2 and i*dx>1):
        Ti[i]=2-i*dx

#Time evolution function using RK3 and 1st order upwind
def evolve(T,Ti):
    global nx,a
    k1=sp.zeros([nx])
    k2=sp.zeros([nx])
    k3=sp.zeros([nx])


    k1[1:-1]=-0.5*(Ti[1 :-1 ]*Ti[1 :-1 ]-Ti[:-2]*Ti[:-2])/(dx)
    Ti[1:-1]=Ti[1:-1]+(8.0/15.0)*dt*k1[1:-1]

    k2[1:-1]=-0.5*(Ti[1 :-1 ]*Ti[1 :-1 ]-Ti[:-2]*Ti[:-2])/(dx)
    Ti[1:-1]=Ti[1:-1]+(5.0/12.0)*dt*k2[1:-1]-(17.0/60.0)*dt*k1[1:-1]

    k3[1:-1]=-0.5*(Ti[1 :-1 ]*Ti[1 :-1 ]-Ti[:-2]*Ti[:-2])/(dx)
    Ti[1:-1]=Ti[1:-1]+(3.0/4.0)*dt*k3[1:-1]-(5.0/12.0)*dt*k2[1:-1]

    return Ti

x=np.linspace(0, 10, nx)
fig,ax=plt.subplots()

points, = ax.plot(x,Ti,color='r',label='Numerical Solution')
text=plt.text(0.9,1,"Burgers Equation using Upwind at t=0",ha='center',va='top',transform = ax.transAxes,fontsize='18')
plt.hold(False)

plt.hold(False)

#main function to plot and calculate our values
for m in range(0, timeStep+1):

    Ti=evolve(T,Ti)

    timeEl=m*dt
    plt.xlabel('x')
    plt.ylabel('u(x)')

    plt.grid(True)
    text.set_text("t=: {0}".format(timeEl))

    plt.title('Burgers Equation using RK3 in time and 1st Order Upwind in Space')

    if(timeEl==0 or timeEl==0.5 or timeEl==1 or timeEl==1.5 or  timeEl==5 or timeEl==10):
        points.set_data(x,Ti)

        fig.savefig('FigureBurgerU'+str(timeEl)+'.png')

    plt.pause(0.000000005)
